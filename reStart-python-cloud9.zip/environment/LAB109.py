inteiro=123456

print(inteiro)

var="responde o professor"

print(var)

decimal=1.45
print(decimal)

